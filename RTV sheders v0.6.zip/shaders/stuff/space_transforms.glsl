//space transforms

// Data from Minecraft / Iris
    uniform mat4 gbufferPreviousProjection;
    uniform mat4 gbufferPreviousModelView;
    uniform mat4 gbufferModelView;
    uniform mat4 gbufferModelViewInverse;
    uniform mat4 gbufferProjection;
    uniform mat4 gbufferProjectionInverse;
	//shadow space transforms
	uniform mat4 shadowModelView;
	uniform mat4 shadowProjection;
	uniform mat4 shadowModelViewInverse;
	float Shadow_map_depth = 256;//-2.0 / shadowProjection[2][2];
	#include "/stuff/shadowmap_distortion.glsl"


// Functions

vec3 project_and_divide( in mat4 m, in vec3 pos ) {
    vec4 homogenous = m * vec4(pos,1.);
    return homogenous.xyz / homogenous.w;
}

vec3 screen_to_view_space(in vec3 screen_pos) {
    return project_and_divide(gbufferProjectionInverse, screen_pos *2. - 1.);
}

vec3 view_to_foot_space(vec3 pos) {
    //standard transform
        //return  ( gbufferModelViewInverse * vec4(pos ,1.) ).xyz;
    //faster transform. the mat3 is the rotational part, and '+ gbufferModelViewInverse[3].xyz' is the camera movement' - both the rotation & movement contain view bob
    return mat3(gbufferModelViewInverse) * pos + gbufferModelViewInverse[3].xyz;
    
}

vec3 view_to_foot_direction(vec3 dir) {
    return  mat3(gbufferModelViewInverse) * dir;
}

// foot position -> shadow-map NDC (-1..1), BEFORE distortion. The shadow projection is orthographic, so w is 1.
vec3 foot_pos_to_shadow_ndc(in vec3 pos)
{
	return (shadowProjection * (shadowModelView * vec4(pos,1.))).xyz;
}

// foot position -> shadow-map texture coordinates (0..1, z = depth), AFTER distortion.
// Biasing is done in shadowmap_sampling.glsl, where the texel size and surface slope are known.
vec3 foot_pos_to_shadowmap_texcoord(in vec3 pos)
{
	vec3 shadowPos = foot_pos_to_shadow_ndc(pos);
	shadowPos = distort(shadowPos); //apply shadow distortion
	return shadowPos * 0.5 + 0.5; //convert from -1 ~ +1 to 0 ~ 1
}
