/*---------------------------------------------------------------------
    RTV volumetric clouds (procedural cumulus)
    ------------------------------------------------------------------
    Ray marched slab of clouds between CLOUD_HEIGHT and CLOUD_HEIGHT + CLOUD_THICKNESS
    (world Y). Only drawn for sky pixels; vanilla clouds are switched off in
    shaders.properties when CLOUD_STYLE == 1. No textures needed, the shape comes
    from hash based value noise.

    returns: rgb = in-scattered cloud light (already in the HDR units of the sky),
             a   = how much of the sky behind is still visible (transmittance)
---------------------------------------------------------------------*/

#ifndef RTV_VOLUMETRIC_CLOUDS_GLSL
#define RTV_VOLUMETRIC_CLOUDS_GLSL

uniform float frameTimeCounter;

#if RTV_PHONE == 1
    #define CLOUD_STEPS_USED 16
    #define CLOUD_LIGHT_STEPS 3
#else
    #if CLOUD_QUALITY == 1
        #define CLOUD_STEPS_USED 20
    #elif CLOUD_QUALITY == 2
        #define CLOUD_STEPS_USED 32
    #else
        #define CLOUD_STEPS_USED 48
    #endif
    #define CLOUD_LIGHT_STEPS 4
#endif

float rtv_cloud_hash13(vec3 p)
{
    p = fract(p * 0.1031);
    p += dot(p, p.zyx + 31.32);
    return fract((p.x + p.y) * p.z);
}

float rtv_cloud_vnoise(vec3 p)
{
    vec3 i = floor(p);
    vec3 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float n000 = rtv_cloud_hash13(i);
    float n100 = rtv_cloud_hash13(i + vec3(1.0, 0.0, 0.0));
    float n010 = rtv_cloud_hash13(i + vec3(0.0, 1.0, 0.0));
    float n110 = rtv_cloud_hash13(i + vec3(1.0, 1.0, 0.0));
    float n001 = rtv_cloud_hash13(i + vec3(0.0, 0.0, 1.0));
    float n101 = rtv_cloud_hash13(i + vec3(1.0, 0.0, 1.0));
    float n011 = rtv_cloud_hash13(i + vec3(0.0, 1.0, 1.0));
    float n111 = rtv_cloud_hash13(i + vec3(1.0, 1.0, 1.0));
    return mix(mix(mix(n000, n100, f.x), mix(n010, n110, f.x), f.y),
               mix(mix(n001, n101, f.x), mix(n011, n111, f.x), f.y), f.z);
}

// wp: world position, h01: 0 at the cloud base, 1 at the top
float rtv_cloud_density(vec3 wp, float h01, bool detail)
{
    vec3 q = wp + vec3(1.0, 0.0, 0.35) * (frameTimeCounter * 3.0 * CLOUD_SPEED);

    // large scale: where the cloud masses are
    vec3 qb = q * vec3(0.0011, 0.0, 0.0011) + vec3(0.0, 0.37, 0.0);
    float base = (0.5 * rtv_cloud_vnoise(qb) + 0.25 * rtv_cloud_vnoise(qb * 2.03 + 7.1) + 0.125 * rtv_cloud_vnoise(qb * 4.1 + 3.3)) / 0.875;

    // medium scale: the puffy billows
    vec3 qs = q * vec3(0.0060, 0.0085, 0.0060);
    float bil = (0.5 * rtv_cloud_vnoise(qs) + 0.25 * rtv_cloud_vnoise(qs * 2.07 + 1.9) + 0.125 * rtv_cloud_vnoise(qs * 4.3 + 5.2)) / 0.875;

    // flat bottom, rounded top
    float prof = smoothstep(0.0, 0.12, h01) * (1.0 - smoothstep(0.40, 1.0, h01));

    float shape = base * 0.55 + bil * 0.45;
    float thr = 0.98 - CLOUD_COVERAGE * 0.52;
    float d = shape * 0.85 + 0.30 * prof - thr;
    d = clamp(d / 0.10, 0.0, 1.0);
    d = d * d * (3.0 - 2.0 * d);

    // fine erosion on the edges (skipped for the light samples)
    if (detail && d > 0.0)
    {
        float det = rtv_cloud_vnoise(q * 0.021);
        d = clamp(d - (1.0 - d) * det * 0.35, 0.0, 1.0);
    }
    return d * sqrt(prof) * CLOUD_DENSITY;
}

float rtv_cloud_hg(float c, float g)
{
    return (1.0 - g * g) / pow(1.0 + g * g - 2.0 * g * c, 1.5);
}

vec4 rtv_volumetric_clouds(in vec3 dir, in vec3 sun_dir, in float jitter)
{
    vec3 cam = cameraPosition;
    float base_y = float(CLOUD_HEIGHT);
    float top_y = base_y + float(CLOUD_THICKNESS);

    if (abs(dir.y) < 1e-4) return vec4(0.0, 0.0, 0.0, 1.0);

    float t0 = (base_y - cam.y) / dir.y;
    float t1 = (top_y - cam.y) / dir.y;
    float tmin = max(min(t0, t1), 0.0);
    float tmax = max(t0, t1);
    if (tmax <= 0.0 || tmin > 6000.0) return vec4(0.0, 0.0, 0.0, 1.0);
    tmax = min(tmax, tmin + 2500.0);

    float dt = (tmax - tmin) / float(CLOUD_STEPS_USED);

    float cos_sun = dot(dir, sun_dir);
    float phase = clamp((rtv_cloud_hg(cos_sun, 0.6) * 0.7 + rtv_cloud_hg(cos_sun, -0.25) * 0.3) * 0.45, 0.0, 4.0);

    // tint of the sky light that fills the clouds from above
    vec3 sky_tint = skyColor * (0.95 / max(max(skyColor.r, skyColor.g), max(skyColor.b, 0.01)));
    vec3 ambient_tint = mix(vec3(0.62, 0.74, 0.95), sky_tint, 0.5);
    vec3 sun_tint = vec3(1.0, 0.97, 0.90);

    float sun_up = smoothstep(-0.03, 0.12, sun_dir.y);

    float trans = 1.0;
    vec3 acc = vec3(0.0);

    for (int s = 0; s < CLOUD_STEPS_USED; s++)
    {
        float t = tmin + (float(s) + jitter) * dt;
        vec3 wp = cam + dir * t;
        float h01 = clamp((wp.y - base_y) / (top_y - base_y), 0.0, 1.0);
        float den = rtv_cloud_density(wp, h01, true);
        if (den > 0.003)
        {
            // how much cloud is between this point and the sun
            float od = 0.0;
            float l = 12.0;
            for (int k = 0; k < CLOUD_LIGHT_STEPS; k++)
            {
                vec3 lp = wp + sun_dir * l;
                float lh = clamp((lp.y - base_y) / (top_y - base_y), 0.0, 1.0);
                od += rtv_cloud_density(lp, lh, false) * l * 0.5;
                l *= 2.2;
            }
            float t_sun = exp(-od * 0.060);
            float powder = 1.0 - exp(-den * 21.0);

            vec3 sun_light = sun_tint * (t_sun * (0.55 + 0.45 * powder)) * phase * 1.9 * sun_up;
            vec3 amb_light = ambient_tint * (0.45 + 0.55 * h01) * 0.9;

            vec3 col = sun_light * rtv_sunlight_factor() * rtv_sun_color() + amb_light * rtv_sky_illumination_factor();

            float a = 1.0 - exp(-den * dt * 0.48);
            acc += trans * a * col;
            trans *= 1.0 - a;
            if (trans < 0.02) break;
        }
    }

    // fade into the sky toward the horizon and with distance
    float fade = exp(-tmin * 0.00022) * smoothstep(0.0, 0.10, abs(dir.y));
    trans = 1.0 - (1.0 - trans) * fade;
    acc *= fade;

    return vec4(acc * CLOUD_BRIGHTNESS, trans);
}

#endif
