// Ray traced block light (torches, lanterns, glowstone, lava, fire...). No vanilla light map is added anywhere.
//
// Every pixel searches the emitter grid and uses two weighted-reservoir samples to estimate nearby block light.
// Visibility rays preserve opaque solid-block shadows while partially transmitting through glass, water, ice and cutout geometry.
// The wider source/fade and multi-sample estimate soften abrupt circular cut-offs without expanding the configured light radius.
#include "/stuff/voxelizing/emitters.glsl"

#if RT_BLOCK_LIGHT_NEE == 1 && RT_API >= 6

// Trace one candidate emitter. The visibility ray now returns material transmittance,
// so cutout foliage and transparent glass/ice softly pass light instead of hard-clipping it.
vec3 rtv_block_light_visibility(in vec3 ray_start, in vec3 p_voxel, in vec3 emitter_pos, in vec3 jitter)
{
	// The flame is a very small area light.  Keeping this offset restrained avoids
	// temporal jitter on the edge of blocks while retaining a real penumbra.
	vec3 target = emitter_pos + jitter * (RT_BLOCK_LIGHT_SOFTNESS * 0.22);
	vec3 to_target = target - p_voxel;
	float target_dist = max(length(to_target), 0.001);
	vec3 target_dir = to_target / target_dist;

	// Stop at the near boundary of the emitter voxel, not at its occupied center.
	float major_dir = max(max(abs(target_dir.x), abs(target_dir.y)), abs(target_dir.z));
	float emitter_entry_distance = 0.5 / max(major_dir, 0.001);
	float visibility_limit = max(target_dist - emitter_entry_distance - 0.07, 0.0);

	if (visibility_limit <= 0.06) return vec3(1.0);

	Traced_shadow_ray light_ray = trace_light_ray(ray_start, target_dir, visibility_limit);
	// Direct emitter light is fully ray traced.  There is no vanilla or fake
	// around-the-corner fill here; any light behind an obstacle comes from GI.
	return light_ray.hit_something ? vec3(RT_BLOCK_LIGHT_WRAP) : clamp(light_ray.tint, vec3(0.0), vec3(1.0));
}

vec3 rtv_block_light_color(in vec3 emitter_pos)
{
	ivec3 emitter_voxel = ivec3(floor(emitter_pos));
	uint emitter_data = imageLoad(cimage1, emitter_voxel).r;
	vec3 flame = vec3(1.0, 0.76, 0.48);
	if (emitter_data == 0u) return flame;
	vec3 source_albedo = max(unpack_albedo_from_voxel(emitter_data), vec3(0.0));
	float source_peak = max(max(source_albedo.r, source_albedo.g), max(source_albedo.b, 0.05));
	vec3 source_chroma = clamp(source_albedo / source_peak, 0.0, 1.0);
	return mix(flame, source_chroma, 0.22);
}

vec3 rt_block_light(in vec3 foot_pos, in vec3 normal_face, in vec3 normal_used, in vec3 dither)
{
	vec3 voxel_offset = vec3(float(VOXEL_AREA) * 0.5) + fract(cameraPosition);
	vec3 ray_start = foot_pos + normal_face * 0.05;
	vec3 p_voxel = ray_start + voxel_offset;
	ivec3 emitter_shift = rtv_emitter_shift(); //cells are locked to the world, see emitters.glsl
	ivec3 center_cell = ivec3(floor((p_voxel + vec3(emitter_shift)) / float(RTV_EMITTER_CELL)));

	float weight_sum = 0.0;
	float candidates = 0.0;
	vec3 chosen_pos_a = vec3(0.0);
	vec3 chosen_pos_b = vec3(0.0);
	bool found_a = false;
	bool found_b = false;

	// Block this surface point belongs to. Used to skip a light block's OWN faces (it already glows by itself).
	ivec3 surface_voxel = ivec3(floor(foot_pos + voxel_offset - normal_face * 0.02));

	for (int dx = -RT_BLOCK_LIGHT_SEARCH; dx <= RT_BLOCK_LIGHT_SEARCH; dx++)
	for (int dy = -RT_BLOCK_LIGHT_SEARCH; dy <= RT_BLOCK_LIGHT_SEARCH; dy++)
	for (int dz = -RT_BLOCK_LIGHT_SEARCH; dz <= RT_BLOCK_LIGHT_SEARCH; dz++)
	{
		ivec3 cell = center_cell + ivec3(dx, dy, dz);
		if (any(lessThan(cell, ivec3(0))) || any(greaterThanEqual(cell, ivec3(RTV_EMITTER_GRID)))) continue;

		uint e = imageLoad(c_image_emitters, cell).r;
		if (e == 0u) continue;

		float level = float((e >> 6u) & 15u);
		ivec3 local = ivec3(int((e >> 4u) & 3u), int((e >> 2u) & 3u), int(e & 3u));
		vec3 emitter_pos = vec3(cell * RTV_EMITTER_CELL + local - emitter_shift) + 0.5;

		vec3 to_emitter = emitter_pos - p_voxel;
		float r2 = dot(to_emitter, to_emitter);
		float r = max(sqrt(r2), 0.001);
		float level_radius = level * 0.55 + 0.5;
		float configured_radius = min(RT_BLOCK_LIGHT_RADIUS + RT_BLOCK_LIGHT_REACH * 2.0, 9.0);
		float nominal_radius = min(level_radius, configured_radius);
		// Do not discard light at a spherical radius.  The previous hard r_max test
		// made a visible circular edge around torches.  The emitter-grid search still
		// bounds cost, while this long inverse-power tail becomes imperceptible naturally.
		if (all(equal(surface_voxel, ivec3(floor(emitter_pos))))) continue;

		float ndl = clamp((dot(normal_used, to_emitter / r) + 0.25) / 1.25, 0.0, 1.0);
		if (ndl <= 0.0) continue;

		float falloff = 1.0 / (1.0 + r2 * 0.30);
		float long_tail = 1.0 / (1.0 + pow(r / max(nominal_radius * 0.80, 0.5), 4.0));
		float w = (level / 15.0) * ndl * falloff * long_tail;

		weight_sum += w;
		candidates += 1.0;

		// Two independent weighted-reservoir picks reduce the all-or-nothing look when
		// one selected torch is occluded but another nearby source has a clear path.
		float rnd_a = fract(dither.x + candidates * 0.7548776662466927 + dither.z * 0.5698402909980532);
		float rnd_b = fract(dither.y + candidates * 0.438289 + dither.x * 0.618034 + dither.z * 0.271828);
		if (rnd_a * weight_sum < w)
		{
			chosen_pos_a = emitter_pos;
			found_a = true;
		}
		if (rnd_b * weight_sum < w)
		{
			chosen_pos_b = emitter_pos;
			found_b = true;
		}
	}

	if ((!found_a && !found_b) || weight_sum <= 0.0) return vec3(0.0);

	vec3 sampled_light = vec3(0.0);
	float sample_count = 0.0;
	if (found_a)
	{
		vec3 jitter_a = dither.yzx - 0.5;
		vec3 visibility_a = rtv_block_light_visibility(ray_start, p_voxel, chosen_pos_a, jitter_a);
		sampled_light += visibility_a * rtv_block_light_color(chosen_pos_a);
		sample_count += 1.0;
	}
	if (found_b)
	{
		vec3 jitter_b = fract(dither.zxy + vec3(0.37, 0.61, 0.83)) - 0.5;
		vec3 visibility_b = rtv_block_light_visibility(ray_start, p_voxel, chosen_pos_b, jitter_b);
		sampled_light += visibility_b * rtv_block_light_color(chosen_pos_b);
		sample_count += 1.0;
	}

	return (sampled_light / max(sample_count, 1.0)) * weight_sum
		* (BLOCK_LIGHT_BRIGHTNESS * RT_BLOCK_LIGHT_BOOST * 0.25);
}
// ---------------------------------------------------------------------------------------------------------------------
// Dynamic held light: a torch / lantern / glowstone... in the main or off hand is a moving light source.
// It uses exactly the same falloff, radius, colour and brightness as a placed block light of the same light level, and one
// ray traced visibility ray, so held light casts real shadows and never shines through walls.
// ---------------------------------------------------------------------------------------------------------------------
#if HELD_LIGHT == 1
	uniform int heldBlockLightValue;  //main hand light level (0 = nothing that emits light)
	uniform int heldBlockLightValue2; //off hand light level

	vec3 rtv_held_light_from(in vec3 light_pos, in float level, in vec3 foot_pos, in vec3 normal_face, in vec3 normal_used, in vec3 dither)
	{
		vec3 ray_start = foot_pos + normal_face * 0.05;
		vec3 to_light = light_pos - ray_start;
		float r2 = dot(to_light, to_light);
		float r = max(sqrt(r2), 0.001);
		vec3 dir = to_light / r;

		float ndl = clamp((dot(normal_used, dir) + 0.25) / 1.25, 0.0, 1.0);
		if (ndl <= 0.0) return vec3(0.0);

		float level_radius = level * 0.55 + 0.5;
		float configured_radius = min(RT_BLOCK_LIGHT_RADIUS + RT_BLOCK_LIGHT_REACH * 2.0, 9.0);
		float nominal_radius = min(level_radius, configured_radius);
		float falloff = 1.0 / (1.0 + r2 * 0.30);
		float long_tail = 1.0 / (1.0 + pow(r / max(nominal_radius * 0.80, 0.5), 4.0));
		float w = (level / 15.0) * ndl * falloff * long_tail;
		if (w < 0.004) return vec3(0.0); //too dim to matter: skip the ray

		// small area light, jittered a little each frame so the shadow edge softens through temporal accumulation
		vec3 target = light_pos + (dither - 0.5) * (RT_BLOCK_LIGHT_SOFTNESS * 0.35);
		vec3 to_target = target - ray_start;
		float target_dist = max(length(to_target), 0.001);
		vec3 target_dir = to_target / target_dist;
		float visibility_limit = target_dist - 0.10;

		vec3 visibility = vec3(1.0);
		if (visibility_limit > 0.06)
		{
			Traced_shadow_ray light_ray = trace_light_ray(ray_start, target_dir, visibility_limit);
			visibility = light_ray.hit_something ? vec3(0.0) : clamp(light_ray.tint, vec3(0.0), vec3(1.0));
		}

		vec3 flame = vec3(1.0, 0.76, 0.48); //same warm colour a placed torch has
		return visibility * flame * w * (BLOCK_LIGHT_BRIGHTNESS * RT_BLOCK_LIGHT_BOOST * 0.25) * HELD_LIGHT_BRIGHTNESS;
	}

	vec3 rtv_held_light(in vec3 foot_pos, in vec3 normal_face, in vec3 normal_used, in vec3 dither)
	{
		vec3 total = vec3(0.0);
		// hand positions in view space (x right, y up, -z forward), then moved into foot space with the same transform as every pixel
		if (heldBlockLightValue >= 3)
		{
			vec3 hand_pos = view_to_foot_space(vec3(0.32, -0.28, -0.45));
			total += rtv_held_light_from(hand_pos, float(min(heldBlockLightValue, 15)), foot_pos, normal_face, normal_used, dither.yzx);
		}
		if (heldBlockLightValue2 >= 3)
		{
			vec3 hand_pos2 = view_to_foot_space(vec3(-0.32, -0.28, -0.45));
			total += rtv_held_light_from(hand_pos2, float(min(heldBlockLightValue2, 15)), foot_pos, normal_face, normal_used, fract(dither.zxy + vec3(0.37, 0.61, 0.83)));
		}
		return total;
	}
#endif

#endif
