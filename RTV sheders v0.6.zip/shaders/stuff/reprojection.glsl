#if TEMPORAL_ACCUMULATION > 0 || RT_DENOISING > 0
	
//Access to the last frame's data
	uniform sampler2D colortex6; // vec4 hdr_color_and_depth_non_clearing - format: RGBA16F
	uniform sampler2D colortex8; // history length: how many frames the accumulated lighting in colortex6 is made of - format: R16F


//Functions
	float sample_last_frames_depth_from_texcoord(in vec2 uv)
	{
		#if RTV_PHONE == 1
			// uninitialized / NaN history on phones: report a far-away depth so the history is rejected
			float last_depth = texture(colortex6,uv).a;
			if(!rtv_valid1(last_depth, 100000.)) last_depth = 100000.;
			return last_depth;
		#else
			return texture(colortex6,uv).a;
		#endif
	}

	vec3 reprojection(in vec3 foot_pos, in float current_depth)
	{
		//reprojection is basically just finding out where this pixel was on screen in the last frame, so that we can sample that data
		
		// we are going to return a vec3, the reprojected texcoord.xy, and a float of how much TA to use
		vec3 reprojected_uv_and_TA;
		
		//first we account for camera movement
		vec3 where_this_was_last_frame = foot_pos + (cameraPosition-previousCameraPosition);

		//then we reproject using the last frame's space transforms
		
		vec4 reprojected_pos;
		
		//first take into account the camera rotation
		reprojected_pos.xyz = (gbufferPreviousModelView* vec4(where_this_was_last_frame.xyz
			//+gbufferModelViewInverse[3].xyz
			,1.)).xyz;

		//then the perspective
		reprojected_pos = gbufferPreviousProjection*vec4(reprojected_pos.xyz,1.);
		float sz = reprojected_pos.z; //we save if it was in front of the camera or behind it, I found this necesary at some point
		reprojected_pos.xyz/=reprojected_pos.w; //apply perspective
		reprojected_pos.xyz=reprojected_pos.xyz*.5+.5; //make into 0.0-1.0 texcoords, from the -1.0-1.0 range

		//now we check if it was on screen last frame
		if( clamp(reprojected_pos.xy,0.,1.) == reprojected_pos.xy && sz>0. )
		{ //was on screen
			
			//now we sample what the distance from the camera was on the last frame, and compare it to what it currently is, if it's the same thing, it should be very close
			
			//we will say that we are going to apply TA (Temporal Accumulation) if they are similar enough
			
			float last_frame_depth_here = sample_last_frames_depth_from_texcoord(reprojected_pos.xy);
			
			reprojected_uv_and_TA = 
				vec3(
					reprojected_pos.xy,
					clamp(
						1. - abs(current_depth-last_frame_depth_here)
						*(10./(1.+current_depth*.1) ) //this factor is the rejection strength based on distance between the last frame and current frame, we are being less strict at a distance to account for precision issues
					,0.,1.)
				);
			
		}//> on screen
		else{//not on screen
			reprojected_uv_and_TA = vec3(0.);
		}//> not on screen
		
		//return data
		return reprojected_uv_and_TA;
		
	}//> function




// First-person hands and held items are camera-attached rather than world-locked.
// Reproject them to the same screen pixel and require a signed hand-depth tag so
// history from the world can never leak into the hand (or vice versa).
vec4 reproject_hand_light(in vec2 screen_uv, in float current_depth, out vec2 reprojected_uv, out float reprojected_count)
{
    reprojected_uv = screen_uv;
    reprojected_count = 0.0;

    vec4 history = texture(colortex6, screen_uv);
    float signed_previous_depth = history.a;
    float previous_depth = abs(signed_previous_depth);

    #if RT_RESOLUTION_DIVIDER > 1 || RT_DENOISING > 0
        reprojected_count = texture(colortex8, screen_uv).r;
        if (!(reprojected_count >= 0.0 && reprojected_count <= 256.0)) reprojected_count = 0.0;
    #endif

    bool previous_pixel_was_hand = signed_previous_depth < -0.0001;
    bool history_color_is_valid = all(lessThan(abs(history.rgb), vec3(100000.0)));
    bool history_depth_is_valid = (signed_previous_depth == signed_previous_depth)
        && previous_depth > 0.0001 && previous_depth < 100000.0;
    float depth_tolerance = 0.01 + 0.008 * max(current_depth, 0.5);
    float depth_difference = abs(current_depth - previous_depth);
    float depth_validity = 1.0 - smoothstep(0.5 * depth_tolerance, depth_tolerance, depth_difference);
    float valid_history = (previous_pixel_was_hand && history_color_is_valid && history_depth_is_valid)
        ? depth_validity : 0.0;

    if (valid_history <= 0.0)
    {
        reprojected_count = 0.0;
        history.rgb = vec3(0.0); // never feed rejected / uninitialized history into the firefly limiter
    }
    return vec4(history.rgb, valid_history);
}

vec4 reproject_bounce_light(in vec3 foot_pos, in float current_depth, out vec2 reprojected_uv, out float reprojected_count)
	{
		// returns last frame's accumulated data (rgb) and a 0-1 validity weight (a); reprojected_uv is where this pixel was on screen last frame
		vec4 reprojected_data_and_TA;
		reprojected_uv = vec2(-1.);
		reprojected_count = 0.;

		//first we account for camera movement
		vec3 where_this_was_last_frame = foot_pos + (cameraPosition-previousCameraPosition);

		//then we reproject using the last frame's space transforms
		vec4 reprojected_pos;
		reprojected_pos.xyz = (gbufferPreviousModelView* vec4(where_this_was_last_frame.xyz,1.)).xyz;
		reprojected_pos = gbufferPreviousProjection*vec4(reprojected_pos.xyz,1.);
		float sz = reprojected_pos.z; //in front of the camera or behind it
		reprojected_pos.xyz/=reprojected_pos.w;
		reprojected_pos.xyz=reprojected_pos.xyz*.5+.5;

		//now we check if it was on screen last frame
		if( clamp(reprojected_pos.xy,0.,1.) == reprojected_pos.xy && sz>0. )
		{ //was on screen
			reprojected_uv = reprojected_pos.xy;
			reprojected_count = texture(colortex8, reprojected_pos.xy).r;

			//the depth data is with the other data, so we will just load it all
			vec4 last_frame_data_here =	texture(colortex6,reprojected_pos.xy);

			#if RTV_PHONE == 1
				// Phone fix: history that is NaN / Inf / out of range is thrown away (zero weight, zero length)
				bool history_is_valid = rtv_valid3(last_frame_data_here.rgb, 100000.)
					&& rtv_valid1(last_frame_data_here.a, 100000.)
					&& rtv_valid1(reprojected_count, 256.);
				if(!history_is_valid)
				{
					last_frame_data_here = vec4(0., 0., 0., 100000.);
					reprojected_count = 0.;
				}
			#endif

			//strict depth rejection, relative to distance: a different surface than last frame means the history is invalid (this is what causes ghost trails)
			float depth_tolerance = (0.02 + 0.015*float(RT_RESOLUTION_DIVIDER)) * max(current_depth, 0.5) + 0.03;
			float depth_difference = abs(current_depth-last_frame_data_here.a);

			reprojected_data_and_TA = vec4(
				last_frame_data_here.rgb,
				1. - smoothstep(0.5*depth_tolerance, depth_tolerance, depth_difference)
			);
			#if RTV_PHONE == 1
				if(!history_is_valid) reprojected_data_and_TA = vec4(0.);
			#endif
		}//> on screen
		else{//not on screen
			reprojected_data_and_TA = vec4(0.);
		}//> not on screen

		return reprojected_data_and_TA;
	}//> function

#endif
// > #if TEMPORAL_ACCUMULATION > 0

