#if defined MISC_FUNCTIONS_LOADED
#else
    #define MISC_FUNCTIONS_LOADED

    //Mod for things other than float
    int modi(in int a, in int b)
    {
	    return a -(a/b)*b;
    }
    ivec3 modiv(in ivec3 a, in ivec3 b)
    {
	    return a -(a/b)*b;
    }

#endif
