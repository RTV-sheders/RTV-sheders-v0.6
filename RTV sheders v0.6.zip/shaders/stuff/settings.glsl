// RTV: Mobile profile quality (phones via Java launchers, MobileGlues / ANGLE)
// MOBILE_MODE is NOT shown in the menu. It is switched on only by the "Mobile" profile
// (profile.MOBILE in shaders.properties) and switched off again by every other profile.
// MOBILE_QUALITY (shown next to the profile selector) is used only while MOBILE_MODE is 1.
#define MOBILE_MODE 0 //[0 1]
#define MOBILE_QUALITY 2 //[1 2 3]
// Placeholder shown (greyed out, one value only) in the menu instead of MOBILE_QUALITY while the Mobile profile is NOT active.
#define MOBILE_QUALITY_LOCKED 0 //[0]
#define MOBILE_DEBUG_VIEW 0 //[0 1]

// RTV_PHONE = 1 when running on a phone: MobileGlues sets MG_MOBILEGLUES by itself, and the Mobile profile
// sets MOBILE_MODE. Everything guarded by RTV_PHONE is a phone-only safety fix. On desktop Java both are
// off, so the compiled code is identical to the original.
#if defined(MG_MOBILEGLUES) || MOBILE_MODE == 1
    #define RTV_PHONE 1
#else
    #define RTV_PHONE 0
#endif

// RTV: stable world lighting and day/night response
// Iris / Minecraft world time, in ticks (0-23999).
uniform int worldTime;
#define NIGHT_LIGHTING_STRENGTH 0.80 //[0.25 0.5 0.65 0.8 1.0 1.2 1.5]

float rtv_day_cycle()
{
    float ticks = mod(float(worldTime), 24000.0);
    return cos((ticks - 6000.0) * (6.28318530718 / 24000.0));
}

// Keep moonlight present, but prevent the sun's daytime intensity from making nights bright.
float rtv_sunlight_factor()
{
    float day_curve = max(rtv_day_cycle(), 0.0);
    float day_strength = smoothstep(0.0, 0.12, day_curve);
    return mix(0.025 * NIGHT_LIGHTING_STRENGTH, 1.0, day_strength);
}

float rtv_sky_illumination_factor()
{
    float day_curve = max(rtv_day_cycle(), 0.0);
    float day_strength = smoothstep(0.0, 0.10, day_curve);
    return mix(0.035 * NIGHT_LIGHTING_STRENGTH, 1.0, day_strength);
}

// The sun stays neutral at noon.  Near the horizon it becomes gently warm,
// with a slightly more orange evening than morning; the low blend amount keeps
// white blocks white instead of turning the whole world into an orange filter.
vec3 rtv_sun_color()
{
    float ticks = mod(float(worldTime), 24000.0);
    float day_curve = max(rtv_day_cycle(), 0.0);
    float daylight = smoothstep(0.0, 0.22, day_curve);
    float horizon = daylight * (1.0 - smoothstep(0.10, 0.50, day_curve));
    float evening = smoothstep(6000.0, 12000.0, ticks);
    vec3 horizon_tint = mix(vec3(1.0, 0.91, 0.76), vec3(1.0, 0.84, 0.64), evening);
    return mix(vec3(1.0), horizon_tint, horizon * 0.62);
}


//Color grading: soft saturation & vibrance (applied at the very end, after tonemapping)
#define SATURATION 1.10 //[0.80 0.90 1.00 1.05 1.10 1.15 1.20 1.30 1.40]
#define VIBRANCE 0.30 //[0.00 0.10 0.20 0.30 0.40 0.50 0.70 1.00]
#define CONTRAST 1.04 //[0.90 0.95 1.00 1.02 1.04 1.06 1.08 1.10]

// Saturation boosts all colors evenly; vibrance boosts dull colors more than already-vivid ones,
// so the image gets richer without neon/oversaturated spots.
vec3 rtv_color_grade(vec3 c)
{
    float luma = dot(c, vec3(0.2126, 0.7152, 0.0722));
    float mx = max(c.r, max(c.g, c.b));
    float mn = min(c.r, min(c.g, c.b));
    float current_sat = (mx - mn) / (mx + 0.0001);
    c = mix(vec3(luma), c, SATURATION);
    c = mix(vec3(luma), c, 1.0 + VIBRANCE * (1.0 - current_sat));
    c = (c - 0.5) * CONTRAST + 0.5;
    return clamp(c, 0.0, 1.0);
}

//Water presentation: animated surface normals and controlled ray-traced reflections.
#define WATER_WAVE_STRENGTH 0.10 //[0.00 0.03 0.04 0.055 0.07 0.10 0.12 0.14]
#define WATER_WAVE_SPEED 0.70 //[0.25 0.40 0.55 0.70 0.85 1.00 1.25]
#define WATER_WAVE_STYLE 1 //[0 1]
#define WATER_TINT 0.55 //[0.0 0.15 0.30 0.45 0.55 0.70 0.85 1.0]
#define WATER_ABSORPTION 1.8 //[0.5 1.0 1.4 1.8 2.5 3.5 5.0]
#define WATER_HISTORY_MAX 0.50 //[0.0 0.30 0.50 0.70 0.85 0.97]
#define WATER_DENOISE_RADIUS 1 //[0 1 2 3 4]
#define WATER_REFLECTION_STRENGTH 0.12 //[0.02 0.04 0.06 0.08 0.10 0.12 0.15 0.20]

//Voxelizing    
    #define VISUALIZED_DATA 6 //[0 1 2 3 4 5 6]
    #define VOXEL_AREA 128 //[32 64 128]

    //set the voxelizing distance that isn't culled off-screen
    #if VOXEL_AREA == 32
        const float voxelDistance = 32.0;
    #endif
    #if VOXEL_AREA == 64
        const float voxelDistance = 64.0;
    #endif
    #if VOXEL_AREA == 128
        const float voxelDistance = 128.0;
    #endif

//RT
    #define RAYTRACING_VIEW 0 //[0 1 2]
    #define VOXELIZED_DEBUG_VIEW 0 //[0 1]
    #define SHADOWS_USED_ON_SCREEN 2 //[0 1 2]
    #define SUN_WIDTH 8.0 //[0.001 0.002 0.003 0.004 0.005 0.007 0.01 0.02 0.03 0.04 0.05 0.06 0.07 0.08 0.09 0.1 0.2 1.0 2.0 3.0 4.0 5.0 6.0 7.0 8.0 9.0 10.0]

    #define USE_TEXTURE_NORMALS 1 //[0 1]
    //Textures in RT
	#define TEXTURES_IN_RT 2 //[0 2 3 5]
	#define IPBR_MIRRORS 1 //[0 1]
	
	//part 5
    #define VOXEL_LODS 1 //[0 1 2 3]
    #define VOXEL_LOD_SQUARE 1 //[0 1]
	
	//part 6
	
	//Shadows - part 7
	#define SOFT_SHADOWMAP_SHADOWS 1 //[0 1]
	#define COLORED_SHADOWS_SHADOWMAP 0 //[0 1]
	#define SHADOW_SMOOTH_PCF 1 //[0 1]
	#define SHADOW_SOFTNESS 1.0 //Classic fixed-grid PCF width in shadow-map texels. [0.5 1.0 1.5 2.0 2.5 3.0 4.0]
	#define SHADOW_FILTER_SAMPLES 4 //Kept for menu compatibility; classic PCF always uses a stable 3x3 grid. [4 6 8 12 16]
	#define GLASS_TINT_EXPONENT 0.5 //[0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
	#define SHADOWS_IN_VOXEL_SCENE 2 //[0 1 2]
    #define SOFT_RT_SHADOWS 1 //[0 1]
    
    #define NO_MIPS_IN_ALPHA 1 //[0 1]
    #define COLORED_RT_SHADOWS 0 //[0 1]
	#define RT_SHADOW_TEXTURES 0 //[0 1]

	//part 8 - Color Spaces
	#define TONEMAPPING 1 //[0 1]
	#define BLOCK_LIGHT_BRIGHTNESS 72.0 //[1.0 3.0 10.0 40.0 60.0 72.0 100.0 150.0 200.0 300.0]
	#define RT_BLOCK_LIGHT_NEE 1 //[0 1]
	#define RT_BLOCK_LIGHT_SEARCH 2 //[1 2 3]
	#define RT_BLOCK_LIGHT_BOOST 1.20 //[0.6 0.8 1.0 1.2 1.5 2.0 3.0]
	#define RT_BLOCK_LIGHT_REACH 0.30 //[0.0 0.1 0.2 0.3 0.5 0.8]
	#define RT_BLOCK_LIGHT_RADIUS 8.0 //[4.0 5.0 6.0 7.0 8.0 9.0]
	#define RT_BLOCK_LIGHT_SOFTNESS 0.30 //Small physical source: stable torch shadows without oversized soft blobs. [0.12 0.2 0.3 0.4 0.6 0.8]
	// Dynamic lighting: torches, lanterns, glowstone etc. held in the main / off hand light up the world (ray traced, with shadows).
	#define HELD_LIGHT 1 //[0 1]
	#define HELD_LIGHT_BRIGHTNESS 1.0 //[0.5 0.75 1.0 1.25 1.5 2.0]
	// Glow of emissive blocks / textures (lamps, lava...). It is added after the denoiser, so it can no longer bleed into neighbouring pixels as a halo.
	#define EMISSION_STRENGTH 2.0 //[1.0 1.25 1.5 1.75 2.0 2.5 3.0]
	#define RT_BLOCK_LIGHT_WRAP 0.0 //No fake light through walls; indirect RT provides the bounce. [0.0 0.05 0.08 0.12 0.18 0.25 0.35]
	#define AO_MODE 1 //[0 1]
	#define AO_STRENGTH 1.0 //[0.25 0.5 0.75 0.85 1.0]
	#define AO_RADIUS 2.0 //[0.5 1.0 1.5 2.0 3.0]
	#define AO_SUN_MIX 0.35 //[0.0 0.15 0.25 0.35 0.50 0.70]
    // Shadowed mobs receive sky ambient fill, while a separate contact AO keeps body details grounded.
    #define ENTITY_SHADOW_FILL 0.48 //[0.15 0.25 0.35 0.40 0.48 0.55 0.65 0.80]
    #define ENTITY_AO_STRENGTH 0.68 //[0.35 0.45 0.55 0.60 0.68 0.75 0.85]
    #define ENTITY_AO_RADIUS 1.55 //[0.75 1.0 1.25 1.5 1.55 1.8 2.0]
	#define UNDERWATER_VISIBILITY 1.0 //[0.5 0.75 1.0 1.5 2.0]
	// Clouds: 0 = vanilla clouds, 1 = volumetric cumulus clouds
	#define CLOUD_STYLE 1 //[0 1]
	#define CLOUD_COVERAGE 0.62 //[0.30 0.40 0.50 0.62 0.72 0.85 1.00]
	#define CLOUD_DENSITY 1.0 //[0.5 0.75 1.0 1.4 2.0 3.0]
	#define CLOUD_HEIGHT 190 //[120 150 170 190 220 260 320]
	#define CLOUD_THICKNESS 80 //[40 60 80 110 150]
	#define CLOUD_SPEED 1.0 //[0.0 0.25 0.5 1.0 1.5 2.0 3.0]
	#define CLOUD_BRIGHTNESS 1.0 //[0.6 0.8 1.0 1.2 1.5]
	#define CLOUD_QUALITY 2 //[1 2 3]
	#define SUN_BRIGHTNESS 180.0 //[1.0 3.0 10.0 100.0 150.0 180.0 200.0 300.0 400.0 500.0 600.0]
	#define SUN_SURFACE_STRENGTH 0.78 //[0.55 0.65 0.72 0.78 0.85 0.92 1.00]
	#define SKY_BRIGHTNESS_IN_RT 0.3 //[0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
	#define EXPOSURE 0 //[0 1 2 3 4 5 6 7 8 9 10 15 20 30 40 50 100]

	
	//part 9 - Global Illumination & Block light Shadows
	#define GLOBAL_ILLUMINATION 2 //[0 2]
	#define GI_STRENGTH 1.65 //[0.75 1.00 1.20 1.40 1.65 1.85 2.10 2.40]
	// Locked off: direct and indirect illumination come from traced emitters,
	// sunlight and sky rays only, never from the vanilla light-map fill.
	#define VANILLA_BLOCK_LIGHT_IN_RT 0
	#define VANILLA_SKY_LIGHT_IN_RT 0
	#define VANILLA_BLOCK_LIGHT_ON_SCREEN 0
	#define VANILLA_SKY_LIGHT_ON_SCREEN 0
	
	//part 10 - Temporal Accumulation & Reprojection
	#define TEMPORAL_ACCUMULATION 2 //[0 1 2]
	#define TEMPORAL_ACCUMULATION_MAX 0.97 //[0.5 0.7 0.8 0.85 0.9 0.92 0.95 0.97 0.98 0.99 1.0]
	#define DITHER_TYPE 3 //[1 2 3]
	#define DEBUG_TA 0 //[0 1]
	#define TA_IS_PBR_AWARE 1 //[0 1]
	#define TA_MOBS 1 //[0 1]
	#define TA_HAND 1 //[0 1]
	#define TA_PBR_REJECTION_EXPONENT 5.0 //[1.0 1.2 1.5 1.7 2.0 3.0 4.0 5.0 10.0]
	
	#define TA_BOOTUP_DELAY 10 //[0 1 5 10 20 50]

	//Part 11 - Upscaling & Denoising for Faster & Cleaner RT
	#define RT_RESOLUTION_DIVIDER 1 //[1 2 4 10 20 100]
	#define RT_DENOISING 1 //[1]
	#define RT_DENOISING_KERNEL_SIZE 4 //[1 2 3 4 5 6 7 8 9 10 11]
	#define KERNEL_FADE 0.3 //[0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
    #define DENOISING_PASSES 2 //[2]
    #define RT_DENOISING_NORMALS_EXP  1.5 //[1.0 1.5 2.0 3.0 4.0 5.0 7.0 10.0 20.0]

	//Part 12 - Glass & Refraction
	#define GLASS_REFRACT_INDEX 0.67 //[0.2 0.3 0.4 0.5 0.6 0.67 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6]
	#define ICE_REFRACT_INDEX 0.76 //[0.5 0.6 0.7 0.76 0.8 0.9 1.0]
	#define GLASS_DISTORTION 0.10 //[0.0 0.04 0.06 0.08 0.10 0.12 0.16 0.20 0.30]
	#define RT_GLASS_TINTING 0 //[0 1]
    #define TA_REFRACTIONS 1 //[0 1]
    #define DENOISE_REFRACTIONS 1 //[0 1]

// ---------------------------------------------------------------------------
// Mobile quality tiers. Must stay at the END of this file: it overrides the
// ray resolution divider and the denoising kernel defined above.
// Only active when the Mobile profile is on (MOBILE_MODE == 1); otherwise this
// block is skipped and the normal option values are used unchanged.
//   1 Low    : ray 1/4 res, short rays, small denoise kernel (fastest)
//   2 Medium : ray 1/4 res, balanced (same as the original Mobile profile)
//   3 High   : ray 1/2 res, longer rays (best image for phones)
//   RT block light search radius (in 4-block cells): Low 1, Medium 2, High 2
// RTV_MOBILE_STEPS is consumed by stuff/rt/rt.glsl (RT_STEPS is defined there).
// ---------------------------------------------------------------------------
#if MOBILE_MODE == 1
    #if MOBILE_QUALITY == 1
        #define RTV_MOBILE_DIVIDER 4
        #define RTV_MOBILE_KERNEL 2
        #define RTV_MOBILE_STEPS 12
        #define RTV_MOBILE_SEARCH 1
    #elif MOBILE_QUALITY == 3
        #define RTV_MOBILE_DIVIDER 2
        #define RTV_MOBILE_KERNEL 3
        #define RTV_MOBILE_STEPS 32
        #define RTV_MOBILE_SEARCH 2
    #else
        #define RTV_MOBILE_DIVIDER 4
        #define RTV_MOBILE_KERNEL 3
        #define RTV_MOBILE_STEPS 20
        #define RTV_MOBILE_SEARCH 2
    #endif
    #undef RT_RESOLUTION_DIVIDER
    #define RT_RESOLUTION_DIVIDER RTV_MOBILE_DIVIDER
    #undef RT_DENOISING_KERNEL_SIZE
    #define RT_DENOISING_KERNEL_SIZE RTV_MOBILE_KERNEL
    #undef RT_BLOCK_LIGHT_SEARCH
    #define RT_BLOCK_LIGHT_SEARCH RTV_MOBILE_SEARCH
#endif

// ---------------------------------------------------------------------------
// Phone safety helpers (RTV_PHONE only).
// Phone GPUs hand out UNINITIALIZED memory for new buffers (desktop drivers give zeros). The history /
// light buffers are never cleared, so the first frame can read NaN / Inf / random values, and
// mix(a, NaN, 0.0) is still NaN, so one bad pixel poisoned the whole image with colorful speckles.
// A value is accepted only if it passes the comparison tests (NaN and Inf always fail them).
// ---------------------------------------------------------------------------
#if RTV_PHONE == 1
    float rtv_safe1(float x, float mx) { return (x >= 0.0 && x <= mx) ? x : 0.0; }
    vec3 rtv_safe3(vec3 c, float mx) { return vec3(rtv_safe1(c.x, mx), rtv_safe1(c.y, mx), rtv_safe1(c.z, mx)); }
    bool rtv_valid1(float x, float mx) { return x >= 0.0 && x <= mx; }
    bool rtv_valid3(vec3 c, float mx) { return rtv_valid1(c.x, mx) && rtv_valid1(c.y, mx) && rtv_valid1(c.z, mx); }
    #define RTV_CLAMP3(c, mx) rtv_safe3((c), (mx))   // replaces an existing clamp(c, 0., mx)
    #define RTV_SAFE3(c, mx) rtv_safe3((c), (mx))    // new check on a value that was read raw before
    #define RTV_SAFE_NEE(c) rtv_safe3((c), 100000.)
#else
    #define RTV_CLAMP3(c, mx) clamp((c), 0., (mx))
    #define RTV_SAFE3(c, mx) (c)                     // desktop: untouched
    #define RTV_SAFE_NEE(c) (c)
#endif

