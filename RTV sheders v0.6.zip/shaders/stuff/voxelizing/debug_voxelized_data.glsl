// Debug Views
	#if VOXELIZED_DEBUG_VIEW == 1
	    // to show voxel range
	    color.r = 1.; 
	    
	    //get voxel map position
	    #define VOXEL_AREA 128 //[32 64 128]
	    #define VOXEL_RADIUS (VOXEL_AREA/2)

	    //get which voxel this is in 2 ways
	    #define VOXEL_POSITION_RECONSTRUCTION_METHOD 2 //[1 2]
	    #if VOXEL_POSITION_RECONSTRUCTION_METHOD == 1
		    //passed from vertex shader
		    ivec3 voxel_pos = ivec3(block_centered_relative_pos+VOXEL_RADIUS);
	    #endif
	    #if VOXEL_POSITION_RECONSTRUCTION_METHOD == 2
		    //reconstructed using foot position & face normals
		    ivec3 voxel_pos = ivec3(foot_pos-normals_face_world*.1+fract(cameraPosition)+VOXEL_RADIUS);
	    #endif
	    
	    //check if in voxel range
	    if( clamp(voxel_pos,0,VOXEL_AREA-1) == voxel_pos )
	    {
		    //get data, unpack, visualize
		    vec4 bytes = unpackUnorm4x8(texture3D(cSampler1, vec3(voxel_pos)/vec3(VOXEL_AREA)).r);	
		    color.rgb = bytes.rgb;
		    

		    #if VISUALIZED_DATA == 4
			    //handle a block differently based on type of block, and checking it's neighbors
			    //thick grass
			    bool grass = bytes.g > .7;
			    bool thick_grass = grass;
			    
			    if(grass)
			    {
				    vec3 neighbor = vec3(1.,0.,0.);
				    bytes = unpackUnorm4x8(texture3D(cSampler1, vec3(voxel_pos+neighbor)/vec3(VOXEL_AREA)).r);	
				    thick_grass = thick_grass && (bytes.g > .7 || bytes.g < .1);
				    
				    neighbor = vec3(-1.,0.,0.);
				    bytes = unpackUnorm4x8(texture3D(cSampler1, vec3(voxel_pos+neighbor)/vec3(VOXEL_AREA)).r);	
				    thick_grass = thick_grass && (bytes.g > .7 || bytes.g < .1);
				    
				    neighbor = vec3(0.,0,1.);
				    bytes = unpackUnorm4x8(texture3D(cSampler1, vec3(voxel_pos+neighbor)/vec3(VOXEL_AREA)).r);	
				    thick_grass = thick_grass && (bytes.g > .7 || bytes.g < .1);
				    
				    neighbor = vec3(0.,0,-1.);
				    bytes = unpackUnorm4x8(texture3D(cSampler1, vec3(voxel_pos+neighbor)/vec3(VOXEL_AREA)).r);	
				    thick_grass = thick_grass && (bytes.g > .7 || bytes.g < .1);
					    
			    }
			    color.rgb = thick_grass? vec3(0.,1.,0.) : grass? vec3(1.,0.,0.) : vec3(.2);
		    #endif
		    
		    //just making the shadow pass run
		    //you don't have to do this if using the 'shadows.enabled' flag in shader.properties
		    vec3 shadow = texture(shadowtex0, texcoord*100.).rgb;
		    if(texcoord.x < .01 && texcoord.y < .01) color.rgb  = shadow;
		    
		    //visualize world position represented in voxel map
		    #define DEBUG_ALIGHNMENT 0 //[0 1]
		    #if DEBUG_ALIGHNMENT == 1
			    color.rgb  = fract(vec3(voxel_pos 
			    + floor(cameraPosition)
			    )/5.);
		    #endif
	    }//> in voxelizing range
    #endif
    //> VOXELIZED_DEBUG_VIEW == 1
