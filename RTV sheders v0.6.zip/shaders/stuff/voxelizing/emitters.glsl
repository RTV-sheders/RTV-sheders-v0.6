// Emitter grid: one small 3D image that remembers, for every 4 x 4 x 4 block cell, the brightest light block inside it
// (torch, lantern, glowstone, lava, fire...). It is written by the shadow pass together with the voxel scene, and read in the
// deferred pass so every pixel can find the light blocks around it and trace a real ray to them (no vanilla light map involved).
//   value = (light level << 6) | (x << 4) | (y << 2) | z      x,y,z = block position inside the cell (0..3). 0 means no emitter.
#ifndef RTV_EMITTERS_INCLUDED
#define RTV_EMITTERS_INCLUDED 1
#if RT_BLOCK_LIGHT_NEE == 1
	layout (r32ui) uniform uimage3D c_image_emitters;
	#define RTV_EMITTER_CELL 4
	#define RTV_EMITTER_GRID (VOXEL_AREA / RTV_EMITTER_CELL)
	// The voxel volume moves with the camera (it is re-centred every time you cross a block border). If the 4x4x4 cells moved with it,
	// the single emitter stored per cell would change whenever you walked, and lights would pop on and off. This shift keeps the cell
	// borders locked to the world (multiples of 4 blocks), so the same emitter always wins in the same cell.
	// Cells are addressed with (voxel + shift) / 4, so one extra row of cells at the far edge is simply dropped (64+ blocks away).
	ivec3 rtv_emitter_shift()
	{
		return ivec3(mod(floor(cameraPosition), vec3(float(RTV_EMITTER_CELL))));
	}
#endif
#endif
