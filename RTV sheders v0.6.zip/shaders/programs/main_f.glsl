// Purpose
	// Main fragment shader:
		// defers data, so we can render the scene more efficiently later, without overdraw
	
// Our Settings
	#include "/stuff/settings.glsl"

// Data from minecraft / iris
	#ifdef MG_MOBILEGLUES
		// GLSL ES melarang initializer pada uniform. Variabel ini tidak dipakai, jadi cukup dideklarasikan.
		uniform float alphaTestRef;
	#else
		uniform float alphaTestRef=0.1;
	#endif
    uniform vec3 cameraPosition;
    uniform vec3 skyColor;
    uniform vec3 shadowLightPosition;
    uniform float frameTimeCounter;
	#if IS_AN_ENTITY == 1
		uniform vec4 entityColor;
	#endif

    uniform mat4 gbufferPreviousProjection;
    uniform mat4 gbufferPreviousModelView;
    uniform mat4 gbufferModelView;
    uniform mat4 gbufferModelViewInverse;
    uniform mat4 gbufferProjection;
    uniform mat4 gbufferProjectionInverse;

// Samplers / textures / images
    uniform sampler2D lightmap;
    uniform sampler2D gtexture;
    uniform sampler2D normals;
    uniform sampler2D specular;

	#if IS_WATER == 1 && IS_CLOUDS != 1 && WATER_WAVE_STYLE == 1
		#include "/stuff/water/unbound_water_waves.glsl"
	#endif

    //the 3d texture we are writing voxel data to
    layout (r32ui) uniform uimage3D cimage1;
    //our 3d image with interpolated voxel data
    uniform usampler3D cSampler1;

    //shadows
    uniform sampler2D shadowcolor0;
    uniform sampler2D shadowtex0;
    uniform sampler2D shadowtex1;



// Data we sent from vertex shader
    in vec2 lmcoord;
    in vec2 texcoord;
    in vec4 glcolor;
	
    in vec3 block_centered_relative_pos;
    in vec3 foot_pos2;
    in vec3 normals_face_world;
	in float material_id;
	in float emission_level;
	in vec4 tangent_world;



// Outputs: where we are rendering/sending data to

    /* RENDERTARGETS:1,2,3,4,5 */

    //this replaces fragdata[], you just set this variable to what you want to output
    //texture data
        layout(location = 0) out vec4 albedo_tex;
		const vec4 colortex1ClearColor = vec4( 0.0 , 0.0 , 0.0 , 0.0 );
		layout(location = 1) out vec4 specular_tex;
        layout(location = 2) out vec4 normals_tex;
    //other defered data
        layout(location = 3) out vec4 defered_data_1_tex; // vec4(lmcoord,ao,height_map); 
		layout(location = 4) out vec4 normals_face_world_and_material_id_tex; //normals_face_world, material id
		// Texture Buffer Formats
        /*
			const int colortex3Format = RGBA16F; 
			const int colortex5Format = RGBA16F; 
		*/

// Included files 
    //#include "/stuff/rt/rt.glsl"
    //#include "/stuff/space_transforms.glsl"
    //#include "/stuff/noise/noise_texture.glsl"



void main() {

    //defer texture data
        //albedo
	    albedo_tex = texture(gtexture, texcoord);
	    albedo_tex.rgb*=glcolor.rgb;
		#if IS_AN_ENTITY == 1
			albedo_tex.rgb = mix(albedo_tex.rgb, entityColor.rgb, entityColor.a);
		#endif
        
        #if NO_MIPS_IN_ALPHA == 1
    	    albedo_tex.a = textureLod(gtexture, texcoord,0).a;
        #endif
        if(albedo_tex.a < .01 ) discard;
	       
        //specular
        specular_tex = texture(specular, texcoord); 
        specular_tex.a = fract(specular_tex.a);//decode alpha of 1.0 as 0 emission
		//light blocks glow themselves, mostly on their bright parts (flame, lamp surface)
		specular_tex.a = max(specular_tex.a, emission_level * smoothstep(0.35, 0.75, dot(albedo_tex.rgb, vec3(0.3333))));
			
		//normals
        normals_tex = texture(normals, texcoord); 
		float ao = normals_tex.b;
		float height_map = normals_tex.a;
		normals_tex.xy=normals_tex.xy*2.-1.;
		normals_tex.z = sqrt(1.0-dot(normals_tex.xy, normals_tex.xy)); //Reconstruct Z
		
        //intergrated pbr
		#if IS_WATER == 1 && IS_CLOUDS != 1
		    if (abs(material_id - 1.0) < 0.5)
		    {
		        specular_tex = vec4(0.98, WATER_REFLECTION_STRENGTH, 1.0, 0.0); // water: clear, smooth ray-traced reflections
		        // water body color: light-cyan (clear) blended toward a deeper blue-green by WATER_TINT, only a hint of biome color
		        albedo_tex.rgb = mix(mix(vec3(0.80, 0.94, 0.98), vec3(0.28, 0.58, 0.70), WATER_TINT), glcolor.rgb, 0.20); // WATER_TINT: dari jernih sampai biru-hijau
		    }
		#else
		    if (abs(material_id - 1.0) < 0.5) specular_tex = vec4(1.0, 0.02, 1.0, 0.0);
		#endif
		#if IPBR_MIRRORS == 1
			if( abs(material_id - 2.) < .5 ) //metals
            {
                // Polished metal, but not a perfect mirror: a little roughness softens the reflection.
                specular_tex = vec4(0.82,0.93,0.0,0.0);
                normals_tex = vec4(0.,0.,1.,1.); 
            }
			if( abs(material_id - 3.) < .5 ) //glass
            {
                specular_tex = vec4(1.,.1,0.,0.); 
                normals_tex = vec4(0.,0.,1.,1.); 
            }
        #endif


		//convert normals to world space
		vec3 tangent2 = normalize(cross(tangent_world.rgb,normals_face_world.xyz)*tangent_world.w);
		mat3 tbn_matrix = mat3(tangent_world.xyz, tangent2.xyz, normals_face_world.xyz);
		normals_tex.xyz = normalize(tbn_matrix * normals_tex.xyz); //Rotate by TBN matrix

		// Fine, narrow, world-locked ripples on the horizontal water surface.
		#if IS_WATER == 1 && IS_CLOUDS != 1
		    #if WATER_WAVE_STYLE == 1
		        // gaya Unbound: hanya untuk air asli, bukan kaca/es yang ikut lewat program water
		        if (normals_face_world.y > 0.55 && abs(material_id - 1.0) < 0.5)
		    #else
		        if (normals_face_world.y > 0.55)
		    #endif
		    {
		        vec3 water_world_pos = foot_pos2 + cameraPosition;
		        vec2 water_xz = water_world_pos.xz;
		        #if WATER_WAVE_STYLE == 1
		            // Gelombang air Unbound: ombak lebar + caustic + sinus berlapis, normal = gradien medan tinggi.
		            // WATER_WAVE_STRENGTH 0.055 = kekuatan sedang; ~0.14 mendekati kekuatan asli di Unbound.
		            vec2 wave_slope = uww_water_slope(water_xz, frameTimeCounter) * (WATER_WAVE_STRENGTH * 3.0);
		            normals_tex.xyz = normalize(normals_tex.xyz + vec3(-wave_slope.x, 0.0, -wave_slope.y));
		        #else
		            float wave_time = frameTimeCounter * WATER_WAVE_SPEED;
		            float wave_x = sin(water_xz.x * 0.78 + water_xz.y * 0.31 + wave_time * 0.78)
		                         + sin(water_xz.x * 0.42 - water_xz.y * 0.86 - wave_time * 0.58)
		                         + 0.28 * sin(water_xz.x * 1.85 + water_xz.y * 1.37 + wave_time * 1.15);
		            float wave_z = cos(water_xz.y * 0.74 - water_xz.x * 0.38 + wave_time * 0.72)
		                         + cos(water_xz.y * 0.47 + water_xz.x * 0.62 - wave_time * 0.54)
		                         + 0.28 * cos(water_xz.y * 1.72 - water_xz.x * 1.46 - wave_time * 1.04);
		            vec3 wave_normal = normalize(vec3(wave_x * WATER_WAVE_STRENGTH, 1.0,
		                                              wave_z * WATER_WAVE_STRENGTH));
		            normals_tex.xyz = normalize(mix(normals_tex.xyz, wave_normal, 0.32));
		        #endif
		    }
		#endif

		// Clear glass: neutral, highly transmissive, with only a restrained Fresnel reflection.
		// Ice: cool deep-blue body color, a slightly stronger soft reflection and mild transmission.
		if (abs(material_id - 3.0) < 0.5)
		{
		    specular_tex = vec4(0.99, 0.045, 0.0, 0.0);
		    albedo_tex.rgb = mix(albedo_tex.rgb, vec3(0.86, 0.93, 0.97), 0.015);
		    albedo_tex.a = min(albedo_tex.a, 0.985);
		}
		if (abs(material_id - 4.0) < 0.5)
		{
		    albedo_tex.rgb = mix(albedo_tex.rgb, vec3(0.015, 0.070, 0.18), 0.48);
		    albedo_tex.a = min(albedo_tex.a, 0.94);
		    specular_tex = vec4(0.91, 0.18, 0.0, 0.0);
		}

		// Gentle animated, world-locked refraction waves. The slow motion resembles water distortion
		// without introducing fast screen-space shimmer or moving noise.
		#if IS_CLOUDS != 1
		    if ((abs(material_id - 3.0) < 0.5 || abs(material_id - 4.0) < 0.5) && GLASS_DISTORTION > 0.0)
		    {
		        vec3 glass_world_pos = foot_pos2 + cameraPosition;
		        vec3 glass_axis = abs(normals_face_world);
		        vec2 gw = glass_axis.y > 0.5 ? glass_world_pos.xz : (glass_axis.x > 0.5 ? glass_world_pos.zy : glass_world_pos.xy);
		        float glass_time = frameTimeCounter * 0.10;
		        vec2 glass_off = vec2(
		            sin(gw.x * 1.15 + gw.y * 0.72 + glass_time) + 0.24 * sin(gw.y * 2.05 - gw.x * 1.31 - glass_time * 0.68),
		            cos(gw.y * 1.07 - gw.x * 0.83 - glass_time * 0.82) + 0.22 * cos(gw.x * 1.76 + gw.y * 1.19 + glass_time * 0.61)
		        );
		        vec3 glass_u = glass_axis.y > 0.5 ? vec3(1., 0., 0.) : vec3(0., 1., 0.);
		        vec3 glass_v = normalize(cross(normals_face_world, glass_u));
		        float is_ice_material = abs(material_id - 4.0) < 0.5 ? 1.0 : 0.0;
		        float material_distortion = mix(0.72, 1.25, is_ice_material);
		        normals_tex.xyz = normalize(normals_tex.xyz + (GLASS_DISTORTION * material_distortion) * (glass_off.x * glass_u + glass_off.y * glass_v));
		    }
		#endif

		//defer other data we want
        defered_data_1_tex = vec4(lmcoord,ao,height_map);
		
		#if IS_HAND == 1
			float material_mask_id = 101.0;
		#elif IS_AN_ENTITY == 1
			float material_mask_id = 100.0;
		#else
            #if IS_CLOUDS == 1
                float material_mask_id = 41.;
            #else
			    float material_mask_id = material_id;
            #endif
		#endif
		
		normals_face_world_and_material_id_tex = vec4(normals_face_world.xyz, material_mask_id);
		
	// Debug Area
		//specular_tex = vec4(1.,0.,0.,1.);//debug
		
}//> main
