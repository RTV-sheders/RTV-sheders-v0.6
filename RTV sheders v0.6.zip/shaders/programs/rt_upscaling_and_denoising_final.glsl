// MIT License: Do Whatever you want to with this code as long as this line stays in the file. This file contains code Copyright © 2026 timetravelbeard (contact: https://www.patreon.com/timetravelbeard , https://youtube.com/@timetravelbeard3588 , https://discord.gg/S6F4r6K5yU )  Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the “Software”), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions: The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software. THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.


// RT Upscaling & Denoising (2 of 2 files)

// Purpose:
	// RT Upscale & Denoising: 

		// When running low res RT or Denoising:
			// the Primary Deferred Pass doesn't add lighting to the scene, it defers it
			// this pass runs. as a last or only denoising / upscaling pass. there is a similiar file for the previous passes, if any
				// this pass samples the defered lighting and applies it
					// because ALL lighting is deferred and then applied here, there will probably be loss of quality in direct lighting vs if it was calculated at full res
						// it would be better to maybe seperate out direct sun lighting since it doesn't have to be RT,
						// but then it wouldn't get denoised here
		
		
	// This could be done a lot better, this is the simplest way to denoise lighting that I could think of


// Our Settings
	#include "/stuff/settings.glsl"

// Data from Minecraft / Iris
    uniform vec3 skyColor;
	uniform vec3 cameraPosition;
	uniform vec3 previousCameraPosition;
	uniform vec3 shadowLightPosition;
	uniform int frameCounter;
	uniform int isEyeInWater;
	uniform vec3 fogColor; //underwater this is the biome's water color
	uniform bool hideGUI;
	uniform ivec2 eyeBrightnessSmooth;
	uniform float viewWidth;
	uniform float viewHeight;
    uniform float frameTimeCounter;
	uniform float near;
	uniform float far;

// Samplers / Textures / Images
	
	//depth
	uniform sampler2D  depthtex0;
	
	//working scene image
    uniform sampler2D colortex0; // scene image
	
	//defered data
    uniform sampler2D colortex1; // albedo
    uniform sampler2D colortex2; // specular tex 
    uniform sampler2D colortex3; // normals tex (in world space) 
    uniform sampler2D colortex4; // defered_data_1_tex; // vec4(lmcoord,ao,height_map);
	uniform sampler2D colortex5; // vec4 normals_face_world, float material_mask_id
	#if DENOISING_PASSES > 1
        //we have flaggedif there are multiple passes, so that we can do things differently 
			//if this is the first and only pass, it needs to sample the (low res) trace Data in colortex6
			//if it is a second or third pass, it needs to sample the upscaled data in colortex7, to process it again
			
        uniform sampler2D colortex7; // full res hdr lighting that is already partially upscaled/denoised
		// we are going to use a define trick to load from a different sampler without having to change the code after thos point 
        #define LIGHT_SAMPLER colortex7
		//we likewise change the variable we use for knowing the resolution of the input
        #define ACTIVE_RT_RESOLUTION_DIVIDER 1 
    #else
		//if this is the first pass, it samples the (low res) colortex6, at its given resolution
        #define LIGHT_SAMPLER colortex6
        #define ACTIVE_RT_RESOLUTION_DIVIDER int(RT_RESOLUTION_DIVIDER)
    #endif
	//the 3d texture we are writing voxel data to
	layout (r32ui) uniform uimage3D cimage1;
	//our 3d image with voxel data as an interpolated sampler
	uniform usampler3D cSampler1;

// Data from Vertex Shader
    in vec2 texcoord;
	
// Global variables
	vec3 Sun_or_moon_dir_world;
	vec3 Dither_offset;

// Outputs
	/* RENDERTARGETS:0 */
	layout(location = 0) out vec4 color;

// Included files 
	#include "/stuff/color/srgb_conversion.glsl"
	#include "/stuff/space_transforms.glsl"
	#include "/stuff/shadowmap_sampling.glsl"
	#define UNPACKING_VOXEL_UVS_HERE 1
	#include "/stuff/uv_packing.glsl"
	#include "/stuff/voxelizing/voxel_packing.glsl"
    #include "/stuff/rt/rt.glsl"
    #include "/stuff/voxelizing/emitters.glsl"
    #include "/stuff/noise/noise_texture.glsl"
	#include "/stuff/noise/noise_functions.glsl"
	#include "/stuff/reprojection.glsl"




// Functions
	void progress_dither()
	{
		#if TEMPORAL_ACCUMULATION > 0
			Dither_offset = fract(Dither_offset + random_from_vec2(gl_FragCoord.xy) );
		#endif
	}
	
	vec3 get_screen_dither()
	{	
		#if DITHER_TYPE == 1 || DITHER_TYPE == 3 
			return blue_noise().xyz;
		#endif
		#if DITHER_TYPE == 2
			return vec3(
				random_from_vec2(gl_FragCoord.xy),
				random_from_vec2(gl_FragCoord.xy*(1.238+texcoord)),
				random_from_vec2(gl_FragCoord.xy*(3.1497+texcoord))
				);
		#endif
	}
	
	float linearize_depth(in float d)
	{
		// from gl_FragCoord.z to world measurements
		return 2.0 * near  * far / (far + near - (2.0 * d - 1.0) * (far - near));
	}
	




#if RTV_PHONE == 1 && MOBILE_DEBUG_VIEW == 0
// Phone fix: the voxel images are cleared here by hand, at the end of the frame, after every ray has been traced.
// Iris clears them with glClearTexImage, which GLES / MobileGlues may not do, leaving random or stale voxels
// (and imageAtomicMax can never lower a value). Stale voxels are what bounced rainbow colors around the scene.
// Every pixel clears a few voxels; the next frame's shadow pass then voxelizes into zeroed images.
void rtv_clear_voxel_images()
{
	int per_frame = max(int(viewWidth) * int(viewHeight), 1);
	int pix = int(gl_FragCoord.y) * int(viewWidth) + int(gl_FragCoord.x);

	const int voxel_total = VOXEL_AREA * VOXEL_AREA * VOXEL_AREA;
	for(int i = pix; i < voxel_total; i += per_frame)
	{
		ivec3 p = ivec3(i % VOXEL_AREA, (i / VOXEL_AREA) % VOXEL_AREA, i / (VOXEL_AREA * VOXEL_AREA));
		imageStore(cimage1, p, uvec4(0u));
	}

	#if RT_BLOCK_LIGHT_NEE == 1
		// the emitter grid (one uint per 4x4x4 blocks)
		const int emitter_total = RTV_EMITTER_GRID * RTV_EMITTER_GRID * RTV_EMITTER_GRID;
		for(int i = pix; i < emitter_total; i += per_frame)
		{
			ivec3 p = ivec3(i % RTV_EMITTER_GRID, (i / RTV_EMITTER_GRID) % RTV_EMITTER_GRID, i / (RTV_EMITTER_GRID * RTV_EMITTER_GRID));
			imageStore(c_image_emitters, p, uvec4(0u));
		}
	#endif

	#if VOXEL_LODS >= 1 && RT_API >= 6
		// the LOD bitmask image: one uint covers a 4 x 2 x 4 block of voxels
		const ivec3 lod_dim = ivec3(VOXEL_AREA / 4, VOXEL_AREA / 2, VOXEL_AREA / 4);
		const int lod_total = lod_dim.x * lod_dim.y * lod_dim.z;
		for(int i = pix; i < lod_total; i += per_frame)
		{
			ivec3 p = ivec3(i % lod_dim.x, (i / lod_dim.x) % lod_dim.y, i / (lod_dim.x * lod_dim.y));
			imageStore(c_image_voxel_lod_1, p, uvec4(0u));
		}
	#endif
}
#endif

// Main Function

void main()
{
	#if RTV_PHONE == 1 && MOBILE_DEBUG_VIEW == 0
		rtv_clear_voxel_images(); // (off while the debug panels are on, they read the voxel image in this same pass)
	#endif
	// This is just Copy-Pasted from the Deferred Primary Pass, and poorly pruned
	
	
	// Setup
	
		vec3 Debug_value; //so we can debug locally coped stuff at the end of the function
		
		#if RAYTRACING_VIEW == 1
			//we are ray tracing the right half of the screen, so ignore it here
			if(texcoord.x<=.5)
			{
		#endif
		#if RAYTRACING_VIEW == 2
			//we are ray tracing the entire screen, so ignore it here
			if(false)
			{
		#endif
        
    // Load data and unpack
		float depth_tex_read = texture(depthtex0,texcoord).r;

		vec4 albedo = texture(colortex1, texcoord);
		vec4 specular_tex = texture(colortex2, texcoord);
		//vec4 defered_data_1_tex = texture(colortex4, texcoord);
		//vec2 lmcoord = defered_data_1_tex.xy;
		vec4 deferred_data2 =  texture(colortex5, texcoord);
		vec3 normals_face_world = deferred_data2.xyz;
		float material_mask_id = deferred_data2.a;
		vec3 normals_texture_world = texture(colortex3, texcoord).xyz;

		bool primary_ray_hit = depth_tex_read <1. && abs(material_mask_id-41.) > .5;

		//unpack 
		albedo.rgb = srgb_to_linear(albedo.rgb);
		float sss = specular_tex.b < 64.5? specular_tex.b/64. : 0.;
		
		float emmission = specular_tex.a * BLOCK_LIGHT_BRIGHTNESS; //emission

	// Setup
	
		vec3 view_dir_world;
		   { //scoped to remove variables from memory as soon as we don't need them anymore
				vec3 direction_screen = vec3(texcoord, 1.);
				vec3 direction_view = screen_to_view_space(direction_screen);
				view_dir_world = normalize( view_to_foot_direction(direction_view) );
			}

		// fix imposible viewing angles from normal textues that point away from the camera
		if( dot(normals_texture_world,view_dir_world) > 0. )  normals_texture_world = normals_face_world;

		#if USE_TEXTURE_NORMALS == 0
			normals_texture_world = normals_face_world;
		#endif
		
		vec3 foot_pos;
		   { //scoped to remove variables from memory as soon as we don't need them anymore
				vec3 position_screen = vec3(texcoord, depth_tex_read);
				vec3 position_view = screen_to_view_space(position_screen);
				foot_pos = view_to_foot_space(position_view);
			}

		//Load a Dither / Randomness / Offset
		Dither_offset = get_screen_dither();
		//change per frame
		#if TEMPORAL_ACCUMULATION > 0
			#if TEMPORAL_ACCUMULATION == 1
				if(hideGUI) Dither_offset = fract(Dither_offset+float(frameCounter % 997)*0.61803398875);
			#else
				Dither_offset = fract(Dither_offset+float(frameCounter % 997)*0.61803398875);
			#endif
		#endif
			
	// Apply our lighting
	
		//get sun direction in the world
		Sun_or_moon_dir_world = normalize(
				view_to_foot_direction(shadowLightPosition)
				 #if SOFT_RT_SHADOWS == 1 && SHADOWS_USED_ON_SCREEN == 1
					+ SUN_WIDTH * (2.*Dither_offset.xyz-1.)
				#endif
			);
					
		//Load & Upscale Lighting
		vec3 lighting_last = RTV_SAFE3(texture(LIGHT_SAMPLER,texcoord).rgb, 10000.);

		#if RT_DENOISING == 1
			// we will manually blend between neighboring samples
			
			//load samples around this point
			ivec2 uv = ivec2(gl_FragCoord.xy);
			ivec2 depth_size = textureSize(depthtex0, 0);
			ivec2 depth_max_uv = max(depth_size - ivec2(1), ivec2(0));
			ivec2 light_size = textureSize(LIGHT_SAMPLER, 0);
			ivec2 light_max_uv = max(light_size - ivec2(1), ivec2(0));
									
			//weigh thier similarity and blend, according to these rules
			
			//initialize the sample pool
			float total_weight = 0.;
			vec3 sampled_color = vec3(0.);
							
			//loop through neighboring pixels
			for(int x = -RT_DENOISING_KERNEL_SIZE ; x<= RT_DENOISING_KERNEL_SIZE ; x++)
			{
				for(int y = -RT_DENOISING_KERNEL_SIZE ; y<= RT_DENOISING_KERNEL_SIZE ; y++)
				{
					// water: the see-through image (sea floor) must stay sharp, so water pixels only blend with their nearest neighbors
					if (abs(material_mask_id - 1.0) < 0.5 && max(abs(x), abs(y)) > WATER_DENOISE_RADIUS) continue;
					//kernel blur 
					float kblur = max(0.0, 1.0 - KERNEL_FADE * (abs(x) + abs(y)) / float(max(1, RT_DENOISING_KERNEL_SIZE + RT_DENOISING_KERNEL_SIZE)));

                    // Keep each pass locally edge-aware; wide strides leave speckles between taps.
                    ivec2 n_uv = clamp(uv + ivec2(x, y) * max(1, ACTIVE_RT_RESOLUTION_DIVIDER),
                                       ivec2(0), depth_max_uv);
                    ivec2 light_uv = clamp(n_uv / ACTIVE_RT_RESOLUTION_DIVIDER, ivec2(0), light_max_uv);
                    vec3 lighting_sample2 = RTV_SAFE3(texelFetch(LIGHT_SAMPLER, light_uv, 0).rgb, 10000.);
                    vec3 normals2 = texelFetch(colortex3, n_uv, 0).rgb;
                    float depth_tex_read2 = texelFetch(depthtex0, n_uv, 0).r;
                    float neighbor_material_mask_id = texelFetch(colortex5, n_uv, 0).a;
					
					// Keep first-person hand/item samples separate from the world behind them.
					float center_is_hand = step(100.5, abs(material_mask_id));
					float neighbor_is_hand = step(100.5, abs(neighbor_material_mask_id));
					float hand_region_match = 1.0 - abs(center_is_hand - neighbor_is_hand);
                    // Mask 100 is a mob/entity; do not mix its denoising samples with terrain.
                    float center_is_entity = 1.0 - step(0.5, abs(material_mask_id - 100.0));
                    float neighbor_is_entity = 1.0 - step(0.5, abs(neighbor_material_mask_id - 100.0));
                    float entity_region_match = 1.0 - abs(center_is_entity - neighbor_is_entity);

					//compare
					float w = kblur* // kernel blur/fade on edges
						pow( max(0., dot(normals2,normals_texture_world) ),RT_DENOISING_NORMALS_EXP) // normals weight
						* max(0., 1. - abs(linearize_depth(depth_tex_read2)-linearize_depth(depth_tex_read)) / (0.25 + 0.10*linearize_depth(depth_tex_read)) ) // depth weight, relative to distance so slopes and far areas still get denoised
						* hand_region_match
						* entity_region_match
						;
					//add to sample pool
					if (x == 0 && y == 0) w = max(w, 0.0001);
					sampled_color += lighting_sample2 * w;
					total_weight += w;
				}
			}
			
			//normalize the sample
			vec3 lighting = clamp(sampled_color / max(total_weight, 0.001), 0.0, 10000.0);
        #else
            vec3 lighting = lighting_last;
		#endif

        #if DENOISE_REFRACTIONS == 0
            if(albedo.a<.999) lighting.rgb = lighting_last.rgb;
        #endif

		//To apply the lighting we need the tint of the bounced light (albedo for diffuse, white for mirror-like reflection).
		// This MUST be smooth and deterministic: it is applied AFTER denoising and temporal accumulation, so nothing can average it out.
		// (It used to be re-rolled here from a random scattered ray direction, which gave every pixel a different random white tint
		// every frame: the white / pink / blue moving dots on grass.)
		// Rough surfaces (grass, dirt, leaves...) have no fresnel sheen, only smooth ones (water, glass, ice, polished metal) do.
		float tint_smoothness = specular_tex.r * specular_tex.r;
		float fresnel = pow( max(0., dot( view_dir_world, reflect(view_dir_world, normals_texture_world))) ,6.) * tint_smoothness;
		float shininess = specular_tex.g +(1.-specular_tex.g)*fresnel;

		//tinting of bounced light, light is tinted when it diffuses into a surface or bounces off metal 
		vec3 tinting = 
			(specular_tex.g>229.6/255.) ? 
			mix(albedo.rgb, vec3(1.), fresnel) //metals
			:
			mix(albedo.rgb, vec3(1.), shininess); //non-metals
		
		
		//Apply the lighting
		color.rgb  = lighting * tinting
			+ emmission * albedo.rgb * EMISSION_STRENGTH; //shiny things are still allowed to glow. Added after denoising so it cannot bleed into neighbours (EMISSION_STRENGTH 2.0 = same brightness as before, when it was added twice)
		#if RTV_PHONE == 1
			color.rgb = rtv_safe3(color.rgb, 1000000.); //phone: a NaN pixel must never reach the screen
		#endif
			
	
	//Sky & background
	
	if(!primary_ray_hit )
	{
	// Add background
		vec4 bg = texture(colortex0, texcoord) ;
		#if TONEMAPPING > 0
			bg.rgb = srgb_to_linear(bg.rgb) * (SUN_BRIGHTNESS * rtv_sky_illumination_factor());
		#endif

		color.rgb = bg.rgb;
	}

	// Underwater volume. Red is absorbed first, then green, so things fade to blue with distance.  The volume includes
	// biome-coloured scattering, world-locked caustics and restrained forward-scattered sun shafts.
	if(isEyeInWater == 1)
	{
		float uw_density = 1.0 / UNDERWATER_VISIBILITY;
		float uw_dist = primary_ray_hit ? length(foot_pos) : 64.0;
		float uw_fog = 1.0 - exp(-uw_dist * 0.035 * uw_density);
		vec3 uw_absorb = exp(-vec3(0.16, 0.055, 0.028) * uw_density * uw_dist);

		// biome-aware water color: a clear blue-teal base, pulled toward the biome's water fog hue
		float uw_biome_max = max(max(fogColor.r, fogColor.g), fogColor.b);
		vec3 uw_hue = uw_biome_max > 0.001 ? fogColor / uw_biome_max : vec3(0.1, 0.45, 1.0);
		vec3 uw_base = vec3(0.05, 0.36, 0.52);
		vec3 uw_color = mix(uw_base, uw_base * (0.35 + 0.65 * uw_hue), 0.5);

		// how much sky light is down here (vanilla light drops by one level per block of water above)
		float uw_sky = clamp(float(eyeBrightnessSmooth.y) / 240.0, 0.0, 1.0);
		float uw_light = mix(0.06, 1.0, uw_sky * uw_sky);
		vec3 uw_scatter = uw_color * SUN_BRIGHTNESS * rtv_sky_illumination_factor() * 0.07 * uw_light;
		float uw_view_to_sun = max(dot(normalize(view_dir_world), Sun_or_moon_dir_world), 0.0);
		float uw_shaft_pattern = 0.62;

		float uw_caustic = 1.0;
		if (primary_ray_hit)
		{
			vec3 uw_world_pos = foot_pos + cameraPosition;
			float caustic_a = sin(uw_world_pos.x * 1.31 + frameTimeCounter * 0.55)
			               * sin(uw_world_pos.z * 1.49 - frameTimeCounter * 0.43);
			float caustic_b = sin((uw_world_pos.x + uw_world_pos.z) * 0.82 - frameTimeCounter * 0.32);
			float floor_mask = smoothstep(0.25, 0.80, abs(normals_face_world.y));
			uw_caustic += 0.08 * floor_mask * smoothstep(0.10, 0.70, 0.5 * caustic_a + 0.5 * caustic_b);
			uw_shaft_pattern = 0.48 + 0.52 * smoothstep(-0.35, 0.75, 0.62 * caustic_a + 0.38 * caustic_b);
		}
		// Forward scattering makes a soft, broken-up shaft only when looking toward
		// the sun through water.  It is gated by real sky light so caves stay dark.
		float uw_shaft_phase = pow(uw_view_to_sun, 6.0);
		vec3 uw_god_rays = rtv_sun_color() * SUN_BRIGHTNESS * rtv_sunlight_factor()
			* (0.0065 * uw_light * uw_fog * uw_shaft_phase * uw_shaft_pattern);
		color.rgb = color.rgb * uw_absorb * mix(vec3(1.0), uw_color / max(max(uw_color.r, uw_color.g), uw_color.b), 0.25)
		          + uw_scatter * uw_fog * uw_caustic + uw_god_rays;
	}
	

	
	#if TONEMAPPING == 1
		#if EXPOSURE == 0
			const float eyeBrightnessHalflife = 30.0;
			float exposure = mix(18.0, 30.0, clamp(float(eyeBrightnessSmooth.y) / 240.0, 0.0, 1.0));
		#else
			float exposure = float(EXPOSURE);
		#endif
		float luminance = (color.r+ color.g+ color.b)/3.;
		color.rgb = color.rgb/(luminance+exposure);
		//screen gamma
		color.rgb = linear_to_srgb(color.rgb);
		color.rgb = rtv_color_grade(color.rgb);
	#endif
	
	
	#if RAYTRACING_VIEW > 0
        }//> close scope of where we ignore part of the screen that are going to be full RT view
//		else{
//			color=vec4(0.);//just write black here if you want to write something, it might become garbage data if you don't, I don't know
//		}
	#endif
	
	
	//Phone debug panels (Advanced > Phone Debug Panels). Three small squares in the top-left corner show which stage of the pipeline works:
	//  1 shadow map   : the sun's depth map. A solid white or solid black square means the shadow pass drew nothing.
	//  2 voxel slice  : the voxel scene around the player, seen from above at foot level. White = solid voxel, red dot = you.
	//                   All dark means nothing was voxelized; random noise means the voxel image holds garbage.
	//  3 light buffer : the ray traced light. Magenta pixels are NaN / Inf / out of range values.
	#if MOBILE_DEBUG_VIEW == 1
	{
		float dbg_size = 0.22;
		float dbg_gap = 0.02;
		vec2 dbg_p = vec2(texcoord.x * viewWidth / viewHeight, 1.0 - texcoord.y);
		for (int dbg_i = 0; dbg_i < 3; dbg_i++)
		{
			vec2 dbg_origin = vec2(dbg_gap + float(dbg_i) * (dbg_size + dbg_gap), dbg_gap);
			vec2 dbg_uv = (dbg_p - dbg_origin) / dbg_size;
			if (dbg_uv.x >= 0.0 && dbg_uv.x <= 1.0 && dbg_uv.y >= 0.0 && dbg_uv.y <= 1.0)
			{
				vec3 dbg_color = vec3(0.0);
				if (dbg_i == 0)
				{
					dbg_color = vec3(texture(shadowtex1, vec2(dbg_uv.x, 1.0 - dbg_uv.y)).r);
				}
				if (dbg_i == 1)
				{
					ivec3 dbg_voxel = ivec3(clamp(int(dbg_uv.x * float(VOXEL_AREA)), 0, VOXEL_AREA - 1), VOXEL_AREA / 2 - 1, clamp(int(dbg_uv.y * float(VOXEL_AREA)), 0, VOXEL_AREA - 1));
					uint dbg_data = imageLoad(cimage1, dbg_voxel).r;
					dbg_color = dbg_data != 0u ? vec3(1.0) : vec3(0.0, 0.0, 0.2);
					if (length(dbg_uv - vec2(0.5)) < 0.02) dbg_color = vec3(1.0, 0.0, 0.0);
				}
				if (dbg_i == 2)
				{
					vec3 dbg_light = texture(LIGHT_SAMPLER, vec2(dbg_uv.x, 1.0 - dbg_uv.y)).rgb;
					bool dbg_ok = dbg_light.r >= 0.0 && dbg_light.r <= 100000.0 && dbg_light.g >= 0.0 && dbg_light.g <= 100000.0 && dbg_light.b >= 0.0 && dbg_light.b <= 100000.0;
					dbg_color = dbg_ok ? clamp(dbg_light * 0.02, 0.0, 1.0) : vec3(1.0, 0.0, 1.0);
				}
				float dbg_edge = min(min(dbg_uv.x, dbg_uv.y), min(1.0 - dbg_uv.x, 1.0 - dbg_uv.y));
				color.rgb = dbg_edge < 0.012 ? vec3(1.0, 1.0, 0.0) : dbg_color;
			}
		}
	}
	#endif

	//Debug Area
		//color.rgb = fract(view_dir_world.rgb*10.);
		//color.rgb = fract(foot_pos+cameraPosition);
		//color.rgb = normals_face_world;
		//color.rgb = Dither_offset;
		//color.rgb = vec3( fract( linearize_depth(depth_tex_read) ) );
		//color.rgb = .5+.5*normals_texture_world;
		//color.rgb = vec3( fract( linearize_depth(depth_tex_read)/far ) );
	
}


