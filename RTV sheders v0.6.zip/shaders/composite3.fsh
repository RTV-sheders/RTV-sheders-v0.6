#version 430 compatibility

#define THIS_DENOISING_PASS 1
#include "/programs/rt_upscaling_and_denoising.glsl"

