#version 430 compatibility

// Same version as shadow.vsh on purpose: mixing a #version 120 fragment stage with a 430 vertex stage is a known
// source of trouble on OpenGL ES translation layers (MobileGlues). The code itself is unchanged.
uniform sampler2D gtexture; //the block atlas (Iris binds it under this name)

varying vec2 lmcoord;
varying vec2 texcoord;
varying vec4 glcolor;

void main() {
	vec4 color = texture2D(gtexture, texcoord) * glcolor;

	// Preserve the texture silhouette in the shadow map: transparent pixels in leaves,
	// cutout blocks and entity skins must not cast the full rectangular texture quad.
	if (color.a < 0.10) discard;

	gl_FragData[0] = color;
}
